var texto = "Observe que essa mensagem vem do módulo";
module.exports=texto;